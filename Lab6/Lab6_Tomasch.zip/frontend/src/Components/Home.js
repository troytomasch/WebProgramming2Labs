import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to the Pokemon Trainer App!</h1>
      <p>
        Click on the Pokemon page to see all the pokemon or the trainers page to
        explore the trainer capabilities! Enjoy!
      </p>
    </div>
  );
};

export default Home;
